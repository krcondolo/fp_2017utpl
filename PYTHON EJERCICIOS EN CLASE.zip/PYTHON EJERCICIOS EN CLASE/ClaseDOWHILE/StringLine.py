#Presentar datos personales
nombre=str(input("Ingrese su nombre:"));
apellidos=str(input("Ingrese sus apellidos"));
edad=int(input("Ingrese su edad"));
ciudad=str(input("Ingrese su ciudad"));
print("Sus datos personales son: ");
print(nombre);
print();
print(apellidos);
print();
print(edad);
print();
print(ciudad);
