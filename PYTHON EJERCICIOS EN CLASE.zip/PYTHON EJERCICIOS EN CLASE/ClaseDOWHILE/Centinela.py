suma=0
bandera=True
while bandera:
    valor=int(input("Ingrese el valor a sumar:"));
    suma=suma+valor
    #Aqui usamos un input para preguntar al ussuario para salir
    salir=int(input("Ingrese -1 para salir:"));
    if salir== -1:
        bandera=False
#Aquí presetnamos el valor final
print("Valores sumados igual a",suma);



