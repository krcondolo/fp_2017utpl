cont=1
suma=0
#Pedimos el valor del limite que tendrá el ciclo
lim=int(input("Ingrese el valor del limite:"));
while cont<=lim:
    suma=suma+cont
    cont+=1
#Presentamos el resultado final
print("El valor de la suma es:", suma);
