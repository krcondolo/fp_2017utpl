#Para usar el ciclo mientras se usa el while y dos puntos ":"
contador=1
while contador<=5:
    print("Valor", contador);
    #Se usa el comando de "+=" que significa un incremento
    contador+=1
