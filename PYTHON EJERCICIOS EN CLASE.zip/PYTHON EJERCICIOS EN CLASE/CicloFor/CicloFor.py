#El ciclo for en phyton se especifica un rango "in range"
for contador in range(1,11):
    #Aquí presentamos los numeros del 1 al 10
    print(contador);
