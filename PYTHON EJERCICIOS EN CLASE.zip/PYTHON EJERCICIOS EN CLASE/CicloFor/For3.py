#Hacer una tabla que imprima el 1 y suma que será 11 (del 1 al 10)
#Hacemos un for que vaya del 1 al 10
for contador in range(1,11):
    #Aquí presentamos en pantalla el contador y usamos el end para que salga horizontal
    print(contador,end='      ');
    #Le sumamos 10 al contador antes de presentarlo al lado
    contador=contador+10
    #Presentamos el contdor ya sumado y saldrá al lado gracias al comando End
    print( contador);








