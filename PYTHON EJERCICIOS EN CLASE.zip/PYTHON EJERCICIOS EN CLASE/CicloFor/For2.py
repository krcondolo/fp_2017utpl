#Ejercicio de presentar numeros del 1 al 10 con opción de vertical u horizontal
opcion=int(input("¿Como quiere ver su reslutado? 1.-Vertical 2.-Horizontal "));
for contador in range(1,11):
    if(opcion==1):
        print(contador);
    #Usamos el comando end para presentar resultados en horizontal
    if(opcion==2):
        print (contador, end=' ');






