suma1=0
suma2=0
numero= int(input("Qué valor quiere sumarle al contador?"));
print("Valor",end='   ');
print("Resultado");
for contador in range(1,11):
    suma1=contador+suma1
    print(contador,end='           ');
    contador2=contador+numero
    suma2=suma2+contador2
    print( contador2);
print("Valor Final",end='   ');
print("Resultado Final");
print(suma1,end='               ');
print(suma2);



