#Ejercicio de suma de números

num1=8
num2=10
suma= num1+num2
print("La suma de los números es:",suma);
