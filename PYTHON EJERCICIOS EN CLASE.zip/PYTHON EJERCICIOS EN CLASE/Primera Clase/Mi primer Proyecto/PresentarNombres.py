#Presentar nombres
nombre="Rene"
apellido="Elizalde"
#Aquí presentamos en pantalla, y se usa diferentes print para hacer un salto de línea
print("Mi nombre es:");print(nombre,apellido);
