#En Phyton la entrada de datos se hace con un comando llamado Input
edad=int(input("Ingrese su edad"));
estatura=float(input("Ingrese su estatura"));
#Podemos darnos cuenta que especificamos el tipo de valor antes de usar input
print("Mi edad es",edad," y mi estatura es",estatura);
#Presentamos en pantalla
