#Entrada de variables
a=int(input("Ingrese el valor de la variable a"));
b=int(input("Ingrese el valor de la variable b"));
c=int(input("Ingrese el valor de la variable c"));
x=10/a+b-3*c
#Presentamos el resultado de la variable
print("El valor de la operacion es:",x);
