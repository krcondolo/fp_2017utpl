#Para usar mas de una condicion utilizamos comandos como And, or, Not
valor=int(input("Ingrese el valor:"));
if valor>=7 and valor<=10:
    print("Aprobado con",valor);
else:
    print("Reprobado con",valor);
