#La sentencia If se usa con el comando if y dos puntos ":"
valor=int(input("Ingrese el valor:"));
if valor>=10:
    print("Aprobado con",valor);
else:
    print("Reprobado con",valor);
