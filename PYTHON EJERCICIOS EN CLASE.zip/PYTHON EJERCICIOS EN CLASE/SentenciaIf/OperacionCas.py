#Entrada de variables para que salga decimal le ponemos double en vez de int
a=float(input("Ingrese el valor de la variable a"));
b=float(input("Ingrese el valor de la variable b"));
c=float(input("Ingrese el valor de la variable c"));
x=10/a+b-3*c
#Presentamos el resultado de la variable
print("El valor de la operacion es:",x);
