/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estudiantee;

import java.util.Scanner;


public class PrincipalCuadrado {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int perimetro = 0;
        for(int a=0; a<5; a++){
            Cuadrado lado = new Cuadrado();    
            System.out.print("Introduzca el lado del cuadrado: ");
            int valor_lado = entrada.nextInt();
            lado.agregar_lado(valor_lado);
            System.out.printf("Cuadrado con lado %d\n Area:%d\n Perimetro:%d\n",lado.obtener_lado(),lado.obtener_area(),lado.obtener_perimetro());
        }
        
        
        
    }
    
}
