/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estudiantee;

/**
 *
 * @author ce
 */
public class Principaal {
       public static void main(String[] args) {
        Estudiantee est = new Estudiantee();
        Estudiantee est2 = new Estudiantee();
        int suma=0;
        double prom;
        String valor_nombre = "Luis";
        est.agregar_nombre(valor_nombre);
        est2.agregar_nombre("Maria");
        est.agregar_edad(18);
        est2.agregar_edad(20);
        suma = est.obtener_edad() + est2.obtener_edad();
        prom = (double)suma/2;
        System.out.println(est.obtener_nombre());
        System.out.println(prom);
    }
    
}

    

