/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estudiantee;

/**
 *
 * @author ce
 */
public class Cuadrado {
    private int lado;
    private int area;
    private int perimetro;
    public void agregar_lado(int l){
        lado = l;
    }
    public int obtener_lado(){
        return lado;
    }
    
    public int obtener_area(){
        area = obtener_lado()*obtener_lado();
        return area;
    }
    public int obtener_perimetro(){
        perimetro = obtener_lado()+obtener_lado()+obtener_lado()+obtener_lado();
        return perimetro;
    }
    
    
}
