/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ce
 */
public class Principal {
    public static void main(String[] args) {
        Estudiante est = new Estudiante();
        Estudiante est2 = new Estudiante();
        int suma = 0;
        double promedio;
        //est.nombre = "Luis";
        //est2.nombre = "Maria";
        est.agregar_nombre("Luis");
        //est.edad = 18;
        //est2.edad = 17;
        //suma = est.edad+est2.edad;
        //promedio = (double)suma/2;
        System.out.println(est.obtener_nombre());
    }
    
}
