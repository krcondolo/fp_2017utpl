#Kevin Condolo
#definimos el arreglo
def arreglos2():

	c = [11,22,43,14]
	suma = 0
    #utilizamos la variable suma para realizar el ejercicio de sumar arreglos
	for i in range(0, 4):
		suma = suma + c[i]
    #imprimimos la suma
	print(suma)

