#Kevin Condolo Jiménez
#EJERCICIO ARREGLO CON EDADES

def arreglos():
	edad = 0
	valores = [0,0,0]
	rangos = ["menores 18", "entre 18 y 25", "mayores a 25"]
	for i in range(0,3):
		edad = int(input("Ingrese las personas %s: " %rangos[i]))
		#Haremos uso del if para ir comparando las edades entre las opcinoes que existen

		if(edad < 18):
			valores[0] = valores[0] + 1
		else:
			if(edad >= 18 and edad <= 25):
				valores[1] = valores[1] + 1
			if(edad > 25):
				valores[2] = valores[2] + 1
		#Le damos la opcion al usuario si quiere seguir ingresar datos

		op = int(input("¿Desea ingresar más datos? 1.-Sí 2.-No"))
		if (op == 1):
			i = len(rangos)
		if(op == 2):
			i = 1
		#imprimimos el resultado en pantalla
		print("El numero de estudiantes de %s\n es %d" %(rangos[i], valores[i]))


