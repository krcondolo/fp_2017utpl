#Kevin Condolo Jiménez
#IMPORTANTE la funcion len devuelve el numero de caracteres en una cadena
#creamos el arreglo numero 3 que usaremos en esta clase

def arreglos3():
	#iniciamos la variable suma en 0 para usarla luego, promedio de la misma manera
	suma = 0
	promedio = 0
	respuesta = [0,0,0,0,0,0,0]
	#creamos los valores del arreglo dias que seran String
	dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
	#creamos el for para pasar el arreglo
	for i in range(0, 7):
		respuesta[i] = int(input("Número de partidos jugados el día %s\n" % dias[i]))
	print("---------------------------")
	for i in range(0, 7):
		suma = suma + respuestaa[i]
		#Usamos la funcion len para saber el numero de caracteres
	promedio = suma / len(respuestaa)
	print("El promedio de partidos jugados es %.2f\n" % promedio)
