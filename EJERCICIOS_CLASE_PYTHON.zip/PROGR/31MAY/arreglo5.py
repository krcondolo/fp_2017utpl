#Kevin Condolo Jiménez
#PROMEDIO CON ARREGLOS


def arreglos():

	suma = 0
	prom = 0
	notas = [0,0,0,0]
	materias = ["Programación", "Matematica", "Contabilidad", "Medicina"]
	for i in range(0, 4):
		notas[i] = input("Ingrese la nota de %s:\n " % materias[i])

	print("---------------------------------")
	for i in range(0,4):
		print("La nota de %s fue %s\n " % (materias[i], notas[i]))
	for i in range(0, 4):
		suma = suma + int(notas[i])

	prom = suma / len(notas)
	print("El promedio de notas es %.2f\n " % prom)
	#Colocamos los if para evaluar las opciones e imprimir diferentes resultados

	if(prom >= 80):
		print("Su promedio es: Sobresaliente")
	if(prom < 80 and prom >= 60):
		print("Su promedio es: bueno")
	if(prom < 60):
		print("Su promedio es: regular")
