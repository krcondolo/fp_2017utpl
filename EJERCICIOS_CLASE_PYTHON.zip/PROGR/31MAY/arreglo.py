#Kevin Condolo
#Ejercicio de impresion de arreglos
def arreglos():

	c = [0, 1, 0, 0, 0]
	for i in range(0, 5):
		print("Posición: %d - Valor: %d\n" %(i, c[i]))

