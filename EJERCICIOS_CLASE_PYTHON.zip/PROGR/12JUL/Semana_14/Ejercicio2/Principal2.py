#Kevin Condolo

#importamos la clase eStudiante1

from Estudiante1 import Estudiante
#Creamos las variables Estudiante
es1 = Estudiante()
es2 = Estudiante()

#Agregamos valores a las variables
suma_edades = 0
promedio = 0
valor_nombre = "Luis"

es1.agregar_nombre(valor_nombre)
es1.agregar_edad(18)
es2.agregar_edad(17)

#Sumamos y llamamos al metodo obtener edad
suma_edades = es1.obtener_edad() + es2.obtener_edad()

promedio = (float(suma_edades)/2)

#Imprimimos los valores en pantalla
print(valor_nombre)
print(promedio)

input()
