#Kevin Condolo

#Creamos la clase estudiante

class Estudiante:
    #Creamos las variables de tipo cdena en nombre
    nombre = ""
    edad = 0
    
