#Kevin Condolo

#Creamos la clase Cuadrado e inciamos el lado porque es igual a todos

class Cuadrado:
    lado=0

    def agregar_lado(self,l):
        self.lado = l

    # Creamos el metodo obtener lado
    def obtener_lado(self):
        return lado;
    # Creamos el metodo para calcular el are
    def calcular_area(self):
        area = self.lado * self.lado
        return area
    #Creamos el metodo para calcular el permietro
    def calcular_perimetro(self):
        perimetro = self.lado + self.lado + self.lado + self.lado;
        return perimetro
