#Kevin Condolo Jiménez
# importar modulo
import trabajador

# variables
nombre = "Raul"
apellido = "Condolo"
cedula = "1104130024"
edad = 20
sueldo_neto = 450.0

trabajador.generar_recibo(nombre, apellido, cedula, edad, sueldo_neto)
   