#Kevin Condolo
#EJERCICIO PARA IMPRIMIR ARREGLO EN BLANCO
def ejercicio1():

	arreglo = [[0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0]]
	for i in range(0, 4):
		for j in range(0, 4):
			print(arreglo[i][j])
		print()


